/**
 * 定义全局变量
 */

// global.API = 'http://localhost:3000' // 测试
// global.WebIP = 'http://localhost:3001' // 测试

global.API = 'https://aileer.net' // 线上
global.WebIP = 'http://47.100.20.218:8080' // 线上

global.adminId = ''

global.wx = {
  code2session: 'https://api.weixin.qq.com/sns/jscode2session',
  // // 测试号
  // appId: 'wx920fde7de872b8d4',
  // secret: '69f6cba186b963701ba2b7f38015a0e9',
  // 申请的Id
  appId: 'wx6b3730d2ffd4a1c2',
  secret: 'd24e39740e320ae54ce284c6f64b614d'
}
