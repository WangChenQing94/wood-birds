/**
 * 定时任务 计算热门城市
 */
const a = require('');